const ITEMS = [
  "54-ФЗ",
  "Регистрация ККТ в ФНС",
  "ОФД",
  "Фискальные накопители",
  "Маркировка «Честный ЗНАК»",
  "ЕГАИС",
  "1С:Предприятие",
  "МЧД",
  "Рутокен",
  "Смарт-терминалы",
];

export function Ticker() {
  return (
    <div className="relative overflow-hidden border-y border-ink-700/60 bg-ink-900/40 py-4">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-ink-950 to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-ink-950 to-transparent" />

      <div className="flex w-max animate-marquee">
        {[0, 1].map((copy) => (
          <ul key={copy} className="flex items-center" aria-hidden={copy === 1}>
            {ITEMS.map((item) => (
              <li
                key={item}
                className="flex items-center gap-6 whitespace-nowrap px-6 text-sm font-medium uppercase tracking-[0.16em] text-mist-500"
              >
                {item}
                <span className="h-1.5 w-1.5 rotate-45 bg-accent/80" />
              </li>
            ))}
          </ul>
        ))}
      </div>
    </div>
  );
}
