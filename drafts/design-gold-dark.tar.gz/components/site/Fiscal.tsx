import Image from "next/image";
import { Reveal } from "@/components/ui/Reveal";
import { RequestButton } from "@/components/site/RequestButton";
import { IconChip, IconClock, IconDoc, IconWrench } from "@/components/ui/Icons";

const TERMS = [
  {
    title: "ФН на 15 месяцев",
    text: "Чаще используют на общей системе налогообложения, при торговле подакцизными товарами и при сезонной работе.",
    model: "Фискальный накопитель на 15 месяцев",
  },
  {
    title: "ФН на 36 месяцев",
    text: "Обычно выбирают на спецрежимах при оказании услуг: реже замена, меньше визитов и бумажной работы.",
    model: "Фискальный накопитель на 36 месяцев",
  },
];

const WORKS = [
  { Icon: IconChip, text: "Подберём срок действия под ваш налоговый режим и вид деятельности" },
  { Icon: IconWrench, text: "Заменим накопитель и активируем новый без остановки торговли" },
  { Icon: IconDoc, text: "Перерегистрируем кассу в ФНС и передадим отчёты в ОФД" },
  { Icon: IconClock, text: "Напомним о сроке окончания заранее, чтобы вы не попали на штраф за просрочку" },
];

export function Fiscal() {
  return (
    <section id="fiscal" className="relative scroll-mt-24 overflow-hidden py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid items-center gap-14 lg:grid-cols-2 lg:gap-16">
          {/* визуал */}
          <Reveal className="order-2 lg:order-1">
            <div className="card card-sheen relative overflow-hidden p-8">
              <div className="bg-grid absolute inset-0 opacity-25" />
              <Image
                src="/products/fn-1-2.png"
                width={1200}
                height={459}
                alt="Фискальные накопители ФН-1.2 на 15 и 36 месяцев"
                sizes="(max-width: 1024px) 90vw, 520px"
                className="relative mx-auto h-auto w-full max-w-md drop-shadow-[0_22px_26px_rgba(0,0,0,0.65)]"
              />

              <div className="relative mt-6 grid grid-cols-2 gap-3">
                <div className="rounded-xl border border-ink-700/70 bg-ink-950/60 px-4 py-3">
                  <p className="font-display text-2xl font-bold text-white">ФФД 1.2</p>
                  <p className="mt-1 text-xs text-mist-500">Поддержка маркировки</p>
                </div>
                <div className="rounded-xl border border-ink-700/70 bg-ink-950/60 px-4 py-3">
                  <p className="font-display text-2xl font-bold text-white">15 / 36</p>
                  <p className="mt-1 text-xs text-mist-500">Месяцев на выбор</p>
                </div>
              </div>
            </div>
          </Reveal>

          {/* текст */}
          <div className="order-1 lg:order-2">
            <Reveal>
              <span className="eyebrow">Фискальные накопители</span>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="mt-5 text-4xl font-semibold leading-tight sm:text-5xl">
                Сердце кассы, которое{" "}
                <span className="text-hl">нельзя просрочить</span>
              </h2>
            </Reveal>
            <Reveal delay={140}>
              <p className="mt-5 text-lg text-mist-400">
                Фискальный накопитель хранит и подписывает каждый чек. Когда срок подходит к концу,
                касса перестаёт работать законно. Мы следим за этим за вас.
              </p>
            </Reveal>

            <div className="mt-9 grid gap-4 sm:grid-cols-2">
              {TERMS.map((term, i) => (
                <Reveal key={term.title} delay={180 + i * 80} className="h-full">
                  <div className="card card-hover flex h-full flex-col p-6">
                    <h3 className="text-lg font-bold">{term.title}</h3>
                    <p className="mt-2.5 text-sm leading-relaxed text-mist-400">{term.text}</p>
                    <div className="mt-auto pt-5">
                      <RequestButton
                        model={term.model}
                        className="inline-flex py-2 text-sm font-semibold text-accent-soft transition-colors hover:text-white"
                      >
                        Запросить условия →
                      </RequestButton>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>

            <ul className="mt-9 space-y-4">
              {WORKS.map(({ Icon, text }, i) => (
                <Reveal key={text} delay={320 + i * 60} as="li">
                  <div className="flex items-start gap-4">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-ink-600 bg-ink-850 text-mist-300">
                      <Icon className="h-5 w-5" />
                    </span>
                    <p className="pt-2 text-[15px] leading-snug text-mist-300">{text}</p>
                  </div>
                </Reveal>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
