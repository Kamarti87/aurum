import { Logo } from "@/components/ui/Logo";
import { ADDRESS, EMAIL, HOURS, LEGAL, MAX, PHONES } from "@/components/site/contacts";

const LINKS = [
  { href: "#services", label: "Услуги" },
  { href: "#devices", label: "Онлайн-кассы" },
  { href: "#fiscal", label: "Фискальные накопители" },
  { href: "#ecp", label: "Электронная подпись" },
  { href: "#contact", label: "Контакты" },
  { href: "#map", label: "Как нас найти" },
];

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t border-ink-700/60 bg-ink-950">
      <div className="mx-auto max-w-7xl px-5 py-14 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[1.2fr_1fr_1fr]">
          <div>
            <Logo variant="full" />
            <p className="mt-5 max-w-sm text-sm leading-relaxed text-mist-500">
              Аурум — современные цифровые решения для бизнеса в Москве и области: онлайн-кассы,
              фискальные накопители, 1С и электронные подписи.
            </p>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-mist-500">
              {ADDRESS.full}
            </p>
          </div>

          <nav>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-mist-400">
              Разделы
            </h3>
            <ul className="mt-4 grid grid-cols-1 gap-y-0.5 sm:grid-cols-2 sm:gap-x-8 lg:grid-cols-1">
              {LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="inline-block py-1.5 text-sm text-mist-500 transition-colors hover:text-white"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-mist-400">
              Контакты
            </h3>
            <p className="mt-4 text-sm text-mist-500">{HOURS.display}</p>
            <ul className="mt-2 space-y-0.5 text-sm">
              {PHONES.map((phone) => (
                <li key={phone.href}>
                  <a
                    href={phone.href}
                    className="inline-block py-1.5 text-mist-500 transition-colors hover:text-white"
                  >
                    {phone.display}
                  </a>
                </li>
              ))}
              <li>
                <a
                  href={`mailto:${EMAIL}`}
                  className="inline-block py-1.5 text-mist-500 transition-colors hover:text-white"
                >
                  {EMAIL}
                </a>
              </li>
              {MAX.href && (
                <li>
                  <a
                    href={MAX.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-block py-1.5 text-mist-500 transition-colors hover:text-white"
                  >
                    Написать в MAX
                  </a>
                </li>
              )}
            </ul>
            <a href="#contact" className="btn btn-ghost mt-6">
              Оставить заявку
            </a>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-3 border-t border-ink-700/60 pt-6 text-xs text-mist-500 sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} {LEGAL.name}. Все права защищены.
            <br className="sm:hidden" />
            <span className="sm:ml-2">
              ИНН {LEGAL.inn} · ОГРНИП {LEGAL.ogrnip}
            </span>
          </p>
          <p>
            <a href="/privacy" className="transition-colors hover:text-white">
              Политика обработки персональных данных
            </a>
          </p>
          <p>
            Цены на сайте не публикуются: стоимость рассчитывается индивидуально под задачу.
          </p>
        </div>
      </div>
    </footer>
  );
}
