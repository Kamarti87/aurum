import { cookies } from "next/headers";
import { ADDRESS } from "@/components/site/contacts";
import { CONSENT_COOKIE, normalize } from "@/components/site/consent";
import { MapEmbed } from "@/components/site/MapEmbed";
import { Reveal } from "@/components/ui/Reveal";
import { IconArrow, IconMapPin } from "@/components/ui/Icons";

export async function MapSection() {
  const consent = normalize((await cookies()).get(CONSENT_COOKIE)?.value);

  return (
    <section id="map" className="relative scroll-mt-24 overflow-hidden border-t border-ink-700/60 py-24 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-14">
          {/* адрес */}
          <div>
            <Reveal>
              <span className="eyebrow">Как нас найти</span>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="mt-5 text-4xl font-semibold leading-tight sm:text-5xl">
                Офис в <span className="text-hl">Москве</span>
              </h2>
            </Reveal>

            <Reveal delay={140}>
              <div className="mt-8 flex items-start gap-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-accent/12 text-accent-soft">
                  <IconMapPin className="h-5 w-5" />
                </span>
                <p className="pt-1 text-lg leading-snug text-white">
                  {ADDRESS.street}
                  <span className="mt-1 block text-[15px] text-mist-400">
                    {ADDRESS.office} · {ADDRESS.city}, Лефортово
                  </span>
                </p>
              </div>
            </Reveal>

            <Reveal delay={260}>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row lg:flex-col xl:flex-row">
                <a
                  href={ADDRESS.route}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-primary"
                >
                  Построить маршрут
                  <IconArrow className="h-4 w-4" />
                </a>
                <a
                  href={ADDRESS.card}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-ghost"
                >
                  Открыть в Яндекс Картах
                </a>
              </div>
            </Reveal>
          </div>

          {/* карта */}
          <Reveal delay={160}>
            <div className="card overflow-hidden p-0">
              <MapEmbed initial={consent} />
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
