import Image from "next/image";
import { Reveal } from "@/components/ui/Reveal";
import { RequestButton } from "@/components/site/RequestButton";
import { IconArrow } from "@/components/ui/Icons";

/** Дата, на которую действует прайс. Меняется вместе с ценами ниже. */
const PRICE_DATE = "1 января 2026 года";

/** Разряды разделяем сами, а не через toLocaleString: результат не должен
    зависеть от локали сервера, иначе разметка на клиенте разъедется. */
function money(value: number) {
  return `${String(value).replace(/\B(?=(\d{3})+(?!\d))/g, " ")} ₽`;
}

type Edition = { label: string; price: number };

type Line = {
  id: string;
  image: { src: string; width: number; height: number };
  /** Высота коробки в витрине. У всех снимков она разная не просто так: «Бухгалтерия»
      снята под углом, видна боковая грань, и при равной высоте коробка кажется мельче
      соседей. Числа подобраны так, чтобы площадь коробок на экране совпадала. */
  scale: string;
  name: string;
  badge: string;
  summary: string;
  editions: Edition[];
  fits: string;
};

const LINES: Line[] = [
  {
    id: "buh",
    image: { src: "/products/1c-buhgalteria.png", width: 509, height: 760 },
    scale: "max-h-[85%]",
    name: "1С:Бухгалтерия 8",
    badge: "Берут чаще всего",
    summary:
      "Учёт, налоги и отчётность на любом режиме налогообложения. Базовой версии хватает одному бухгалтеру, ПРОФ нужна, когда работают несколько человек или требуются доработки.",
    editions: [
      { label: "Базовая", price: 4900 },
      { label: "ПРОФ", price: 23000 },
      { label: "ПРОФ, комплект на 5 пользователей", price: 45500 },
      { label: "Для некоммерческих организаций, ПРОФ", price: 25300 },
      { label: "Для государственных учреждений, ПРОФ", price: 25400 },
    ],
    fits: "ИП и компании на любой системе налогообложения",
  },
  {
    id: "zup",
    image: { src: "/products/1c-zup.png", width: 449, height: 656 },
    scale: "max-h-[87%]",
    name: "1С:Зарплата и управление персоналом 8",
    badge: "Кадры и выплаты",
    summary:
      "Расчёт зарплаты, отпусков и больничных, кадровый учёт и отчётность по сотрудникам. Считает взносы и НДФЛ, готовит документы для проверяющих.",
    editions: [
      { label: "Базовая", price: 11100 },
      { label: "ПРОФ", price: 39700 },
    ],
    fits: "Компании с наёмными сотрудниками",
  },
  {
    id: "roznica",
    image: { src: "/products/1c-roznica.png", width: 486, height: 660 },
    scale: "max-h-[82%]",
    name: "1С:Розница 8",
    badge: "Для торговой точки",
    summary:
      "Товароучёт для магазина: приёмка, остатки, цены и скидки. Дружит с онлайн-кассой, маркировкой «Честный знак» и ЕГАИС — тем, что мы и так настраиваем.",
    editions: [
      { label: "Базовая", price: 4900 },
      { label: "ПРОФ", price: 23000 },
    ],
    fits: "Магазины и точки продаж с кассой",
  },
  {
    id: "ut",
    image: { src: "/products/1c-ut.png", width: 371, height: 499 },
    scale: "max-h-[82%]",
    name: "1С:Управление торговлей 8",
    badge: "Опт и склад",
    summary:
      "Закупки, склад, продажи и взаиморасчёты в одной программе. Подходит, когда товар идёт через несколько складов, а сделок и контрагентов становится много.",
    editions: [
      { label: "Базовая", price: 10000 },
      { label: "ПРОФ", price: 39700 },
    ],
    fits: "Оптовая и розничная торговля со складом",
  },
  {
    id: "unf",
    image: { src: "/products/1c-unf.png", width: 300, height: 402 },
    scale: "max-h-[82%]",
    name: "1С:Управление нашей фирмой 8",
    badge: "Весь бизнес целиком",
    summary:
      "Продажи, склад, деньги, заказы и работа сотрудников в одном окне. Берут, когда хочется вести всю фирму в одной программе, а не собирать её из нескольких.",
    editions: [
      { label: "Базовая", price: 7000 },
      { label: "ПРОФ", price: 30600 },
    ],
    fits: "Малый бизнес: услуги, производство, торговля",
  },
];

const EXTRAS: { title: string; note: string; items: Edition[] }[] = [
  {
    title: "Дополнительные рабочие места",
    note: "Нужны, когда в программе работает больше одного человека. Покупаются к любой версии ПРОФ.",
    items: [
      { label: "Клиентская лицензия на 1 рабочее место", price: 9400 },
      { label: "Клиентская лицензия на 5 рабочих мест", price: 31800 },
      { label: "Клиентская лицензия на 10 рабочих мест", price: 60900 },
    ],
  },
  {
    title: "Серверные компоненты",
    note: "Требуются при работе в клиент-серверном режиме: когда база большая, а пользователей много.",
    items: [
      { label: "Сервер МИНИ на 5 подключений", price: 21300 },
      { label: "ПРОФ, лицензия на сервер", price: 74100 },
      { label: "ПРОФ, лицензия на сервер (x86-64)", price: 126800 },
    ],
  },
];

export function OneC() {
  return (
    <section id="onec" className="relative scroll-mt-24 overflow-hidden py-24 lg:py-32">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="orb right-0 top-24 h-[480px] w-[480px] text-accent/14" />
      </div>

      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <Reveal>
              <span className="eyebrow">Программы 1С</span>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="mt-5 text-4xl font-semibold leading-tight sm:text-5xl">
                1С:Предприятие 8 <span className="text-hl">с ценами</span>
              </h2>
            </Reveal>
            <Reveal delay={140}>
              <p className="mt-5 text-lg text-mist-400">
                Продаём лицензии, внедряем и сопровождаем. Подскажем, какой версии хватит под
                вашу задачу, — переплачивать за ПРОФ там, где хватит базовой, незачем.
              </p>
            </Reveal>
          </div>

          <Reveal delay={200}>
            <a href="#contact" className="btn btn-ghost">
              Не знаете, что выбрать? Поможем
              <IconArrow className="h-4 w-4" />
            </a>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {LINES.map((line, i) => (
            <Reveal key={line.id} delay={i * 90} className="h-full">
              <article className="card card-sheen card-hover group flex h-full flex-col overflow-hidden">
                <div className="relative flex h-72 items-center justify-center overflow-hidden border-b border-ink-700/60 bg-ink-950/40">
                  <div className="bg-grid absolute inset-0 opacity-25" />
                  <div className="absolute inset-0 bg-[radial-gradient(62%_52%_at_50%_36%,rgba(255,255,255,0.08),transparent_72%)]" />
                  <span className="absolute left-5 top-5 z-10 rounded-full border border-ink-600 bg-ink-950/85 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-mist-300">
                    {line.badge}
                  </span>
                  <Image
                    src={line.image.src}
                    width={line.image.width}
                    height={line.image.height}
                    alt={`Коробка ${line.name}`}
                    sizes="(max-width: 640px) 60vw, (max-width: 1024px) 30vw, 220px"
                    className={`relative ${line.scale} w-auto object-contain drop-shadow-[0_22px_26px_rgba(0,0,0,0.65)] transition-transform duration-500 ease-out group-hover:-translate-y-1.5 group-hover:scale-[1.03]`}
                  />
                </div>

                <div className="flex flex-1 flex-col p-7">
                  <h3 className="text-xl font-bold leading-snug">{line.name}</h3>
                  <p className="mt-3 text-[15px] leading-relaxed text-mist-400">{line.summary}</p>

                  <dl className="mt-6 space-y-2.5 border-t border-ink-700/60 pt-5">
                    {line.editions.map((edition) => (
                      <div key={edition.label} className="flex items-baseline justify-between gap-4">
                        <dt className="text-sm text-mist-400">{edition.label}</dt>
                        <dd className="shrink-0 font-display text-[15px] font-bold text-white">
                          {money(edition.price)}
                        </dd>
                      </div>
                    ))}
                  </dl>

                  <p className="mt-6 rounded-xl border border-ink-700/70 bg-ink-950/50 px-4 py-3 text-sm text-mist-400">
                    <span className="font-semibold text-mist-200">Подойдёт: </span>
                    {line.fits}
                  </p>

                  {/* распорка прижимает кнопку к низу: у линеек разное число
                      версий, без неё кнопки в ряду встали бы вразнобой */}
                  <div className="mt-7 flex-1" />
                  <RequestButton model={line.name}>Оставить заявку</RequestButton>
                </div>
              </article>
            </Reveal>
          ))}

        </div>

        <div className="mt-5 grid gap-5 lg:grid-cols-2">
          {EXTRAS.map((group, i) => (
            <Reveal key={group.title} delay={i * 90} className="h-full">
              <div className="card flex h-full flex-col p-7">
                <h3 className="text-lg font-bold">{group.title}</h3>
                <p className="mt-2.5 text-sm leading-relaxed text-mist-400">{group.note}</p>

                <dl className="mt-6 space-y-3">
                  {group.items.map((item) => (
                    <div
                      key={item.label}
                      className="flex items-baseline justify-between gap-4 border-b border-ink-700/50 pb-3 last:border-0 last:pb-0"
                    >
                      <dt className="text-sm text-mist-300">{item.label}</dt>
                      <dd className="shrink-0 font-display text-[15px] font-bold text-white">
                        {money(item.price)}
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={120}>
          <div className="mt-10 grid gap-4 rounded-2xl border border-ink-700/60 bg-ink-900/40 px-6 py-6 text-sm text-mist-400 sm:grid-cols-2 lg:px-8">
            <p>
              <span className="font-semibold text-mist-200">Поставка электронная. </span>
              На карточках показаны коробочные издания, а цены выше — на электронные:
              программа приходит на почту, везти ничего не нужно, работать можно в тот же день.
            </p>
            <p>
              <span className="font-semibold text-mist-200">Настроим и научим. </span>
              Установим, перенесём данные, свяжем с кассой. Консультации и доработки —{" "}
              {money(2300)} в час.
            </p>
            <p className="sm:col-span-2 text-mist-500">
              В прайс вошли не все программы фирмы «1С» — если нужной нет в списке, спросите,
              подберём и посчитаем. Цены указаны на {PRICE_DATE} и не являются публичной офертой:
              актуальную стоимость подтвердим до оплаты.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
