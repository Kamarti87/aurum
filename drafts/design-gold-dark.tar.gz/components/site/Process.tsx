import { Reveal } from "@/components/ui/Reveal";

const STEPS = [
  {
    n: "01",
    title: "Заявка и консультация",
    text: "Уточняем вид деятельности, налоговый режим и то, как вы торгуете сейчас. Без шаблонных ответов.",
  },
  {
    n: "02",
    title: "Подбор решения",
    text: "Предлагаем кассу, фискальный накопитель, программное обеспечение и подписи. Ровно то, что нужно, без лишнего.",
  },
  {
    n: "03",
    title: "Поставка и регистрация",
    text: "Привозим оборудование, ставим ККТ на учёт в ФНС, подключаем ОФД, настраиваем 1С и рабочие места.",
  },
  {
    n: "04",
    title: "Обслуживание",
    text: "Остаёмся на связи: техподдержка, замена накопителя, обновления, ремонт и перерегистрация.",
  },
];

export function Process() {
  return (
    <section id="process" className="relative scroll-mt-24 overflow-hidden py-24 lg:py-32">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="orb right-0 top-1/4 h-[420px] w-[420px] text-accent/12" />
      </div>

      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="max-w-2xl">
          <Reveal>
            <span className="eyebrow">Как мы работаем</span>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="mt-5 text-4xl font-semibold leading-tight sm:text-5xl">
              Четыре шага <span className="text-hl">до готовой кассы</span>
            </h2>
          </Reveal>
        </div>

        <ol className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {STEPS.map((step, i) => (
            <Reveal key={step.n} delay={i * 90} as="li" className="h-full">
              <div className="card card-sheen card-hover group relative h-full p-7">
                <span className="font-display text-5xl font-semibold text-transparent [-webkit-text-stroke:1.5px_var(--color-ink-600)] transition-all duration-500 group-hover:[-webkit-text-stroke:1.5px_var(--color-accent)]">
                  {step.n}
                </span>
                <h3 className="mt-5 text-xl font-bold">{step.title}</h3>
                <p className="mt-3 text-[15px] leading-relaxed text-mist-400">{step.text}</p>

                {i < STEPS.length - 1 && (
                  <span className="absolute right-6 top-9 hidden h-px w-10 bg-gradient-to-r from-ink-600 to-transparent lg:block" />
                )}
              </div>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
}
