import { Reveal } from "@/components/ui/Reveal";
import { IconArrow, IconCash, IconCube, IconKey } from "@/components/ui/Icons";

const SERVICES = [
  {
    id: "1c",
    title: "1С",
    tagline: "Продажа, внедрение, обслуживание",
    Icon: IconCube,
    points: [
      "Подбор и поставка лицензий 1С",
      "Внедрение и настройка под процессы компании",
      "Обновления, доработки и сопровождение",
      "Интеграция 1С с кассовым оборудованием",
    ],
    accent: "from-accent/18 to-transparent",
  },
  {
    id: "kkt",
    title: "ККТ",
    tagline: "Продажа, постановка на учёт, полное ТО",
    Icon: IconCash,
    points: [
      "Подбор кассы под вид деятельности",
      "Постановка на учёт в ФНС и подключение ОФД",
      "Замена фискального накопителя и перерегистрация",
      "Полное техническое обслуживание и ремонт",
    ],
    accent: "from-accent/18 to-transparent",
  },
  {
    id: "ecp",
    title: "ЭЦП",
    tagline: "Физлица, МЧД, ЕГАИС, Рутокен",
    Icon: IconKey,
    points: [
      "Электронная подпись для физических лиц",
      "Машиночитаемые доверенности (МЧД)",
      "Подписи для ЕГАИС и работы с алкоголем",
      "Носители Рутокен, настройка рабочего места",
      "КриптоПро CSP — программа для формирования и проверки подписей",
    ],
    accent: "from-accent/18 to-transparent",
  },
];

export function Services() {
  return (
    <section id="services" className="relative scroll-mt-24 py-24 lg:py-32">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="max-w-2xl">
          <Reveal>
            <span className="eyebrow">Наши услуги</span>
          </Reveal>
          <Reveal delay={80}>
            <h2 className="mt-5 text-4xl font-semibold leading-tight sm:text-5xl">
              Ваши задачи — <span className="text-hl">наше решение</span>
            </h2>
          </Reveal>
          <Reveal delay={140}>
            <p className="mt-5 text-lg text-mist-400">
              Три направления, которые закрывают техническую и учётную рутину бизнеса:
              от кассы на прилавке до подписи в отчётности.
            </p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-5 lg:grid-cols-3">
          {SERVICES.map(({ id, title, tagline, Icon, points, accent }, i) => (
            <Reveal key={id} delay={i * 100} className="h-full">
              <article className="card card-sheen card-hover group flex h-full flex-col overflow-hidden p-7">
                <div
                  className={`pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-gradient-to-br ${accent} blur-2xl transition-opacity duration-500 group-hover:opacity-100 opacity-70`}
                />

                <div className="relative flex items-center gap-4">
                  <span className="flex h-12 w-12 items-center justify-center rounded-2xl border border-ink-600 bg-ink-950/60 text-accent-soft">
                    <Icon className="h-6 w-6" />
                  </span>
                  <div>
                    <h3 className="text-2xl font-bold">{title}</h3>
                    <p className="mt-0.5 text-sm text-mist-500">{tagline}</p>
                  </div>
                </div>

                <ul className="relative mt-7 space-y-3">
                  {points.map((point) => (
                    <li key={point} className="flex gap-3 text-[15px] leading-snug text-mist-300">
                      <span className="mt-[9px] h-px w-3 shrink-0 bg-accent" />
                      {point}
                    </li>
                  ))}
                </ul>

                <a
                  href="#contact"
                  className="relative mt-auto inline-flex items-center gap-2 pt-8 text-sm font-semibold text-white transition-colors hover:text-accent-soft"
                >
                  Обсудить задачу
                  <IconArrow className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                </a>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
