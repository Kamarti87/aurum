import Image from "next/image";
import { Reveal } from "@/components/ui/Reveal";
import { IconArrow, IconCheck, IconSpark } from "@/components/ui/Icons";

const HIGHLIGHTS = [
  "ККТ под ключ: подбор, продажа, регистрация в ФНС",
  "1С: продажа, внедрение, обслуживание",
  "ЭЦП: физлица, МЧД, ЕГАИС, Рутокен",
];

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-[74px]">
      {/* фон */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="bg-grid mask-fade absolute inset-0 opacity-60" />
        <div className="orb -left-24 top-[-120px] h-[420px] w-[420px] text-accent/16" />
        <div className="orb right-[-80px] top-[40px] h-[420px] w-[420px] text-accent/14" />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-ink-950" />
      </div>

      <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 pb-20 pt-14 lg:grid-cols-[1.05fr_0.95fr] lg:gap-8 lg:px-8 lg:pb-28 lg:pt-20">
        {/* текст */}
        <div>
          <Reveal>
            <span className="eyebrow">
              <IconSpark className="h-3.5 w-3.5" />
              Аурум · Москва и область
            </span>
          </Reveal>

          <Reveal delay={80}>
            <h1 className="mt-6 text-[2.6rem] font-semibold leading-[1.05] sm:text-6xl lg:text-[4.1rem]">
              Онлайн-кассы,
              <br />
              1С и ЭЦП{" "}
              <span className="text-hl">под ключ</span>
            </h1>
          </Reveal>

          <Reveal delay={160}>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-mist-300">
              Мы команда, которая создаёт современные цифровые решения для бизнеса и помогает
              достигнуть новых высот. Подберём кассу и фискальный накопитель, поставим на учёт,
              возьмём на обслуживание. Дальше вы просто работаете.
            </p>
          </Reveal>

          <Reveal delay={240}>
            <ul className="mt-8 flex flex-col gap-3">
              {HIGHLIGHTS.map((item) => (
                <li key={item} className="flex items-start gap-3 text-[15px] text-mist-200">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-accent/15 text-accent-soft">
                    <IconCheck className="h-3.5 w-3.5" />
                  </span>
                  {item}
                </li>
              ))}
            </ul>
          </Reveal>

          <Reveal delay={320}>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row">
              <a href="#contact" className="btn btn-primary">
                Получить консультацию
                <IconArrow className="h-4 w-4" />
              </a>
              <a href="#devices" className="btn btn-ghost">
                Смотреть онлайн-кассы
              </a>
            </div>
          </Reveal>

          <Reveal delay={380}>
            <p className="mt-6 text-sm text-mist-500">
              Ответим в течение рабочего дня и подберём решение под ваш вид деятельности.
            </p>
          </Reveal>
        </div>

        {/* композиция с техникой */}
        <Reveal delay={200} className="relative">
          <div className="relative mx-auto aspect-square w-full max-w-[560px]">
            <div className="orb left-[58%] top-[40%] h-[60%] w-[62%] -translate-x-1/2 -translate-y-1/2 text-accent/20" />

            {/* флагман */}
            <div className="absolute right-0 top-[38%] w-[88%] -translate-y-1/2 animate-float-slow">
              <Image
                src="/products/sigma-10.webp"
                width={698}
                height={514}
                alt="Смарт-терминал АТОЛ Sigma 10"
                priority
                sizes="(max-width: 1024px) 88vw, 500px"
                className="h-auto w-full drop-shadow-[0_36px_44px_rgba(0,0,0,0.75)]"
              />
            </div>

            {/* компактная модель на переднем плане */}
            <div className="absolute -left-6 bottom-[6%] w-[50%] animate-float-soft sm:-left-2">
              <Image
                src="/products/sigma-7.webp"
                width={589}
                height={458}
                alt="Смарт-терминал АТОЛ Sigma 7"
                sizes="(max-width: 1024px) 54vw, 300px"
                className="h-auto w-full drop-shadow-[0_28px_36px_rgba(0,0,0,0.8)]"
              />
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
