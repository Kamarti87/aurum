"use client";

import { useEffect, useState } from "react";
import { Logo } from "@/components/ui/Logo";
import { PHONES } from "@/components/site/contacts";
import { IconPhone } from "@/components/ui/Icons";

const NAV = [
  { href: "#services", label: "Услуги" },
  { href: "#devices", label: "Онлайн-кассы" },
  { href: "#fiscal", label: "Накопители" },
  { href: "#onec", label: "1С" },
  { href: "#ecp", label: "ЭЦП" },
  // только в мобильном меню: на десктопе карта доступна из подвала
  { href: "#map", label: "Как нас найти", mobileOnly: true },
];

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "border-b border-ink-700/70 bg-ink-950/80 backdrop-blur-md"
          : "border-b border-transparent"
      }`}
    >
      <div className="mx-auto flex h-[74px] max-w-7xl items-center justify-between px-5 lg:px-8">
        <a href="#top" className="shrink-0" aria-label="Аурум, на главную">
          <Logo />
        </a>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.filter((item) => !item.mobileOnly).map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium text-mist-300 transition-colors hover:bg-ink-800/70 hover:text-white"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href={PHONES[0].href}
            className="hidden text-[15px] font-semibold text-white transition-colors hover:text-mist-300 xl:block"
          >
            {PHONES[0].display}
          </a>

          <a href="#contact" className="btn btn-primary hidden sm:inline-flex">
            Оставить заявку
          </a>

          {/* на телефоне звонок важнее формы — выносим отдельной кнопкой */}
          <a
            href={PHONES[0].href}
            aria-label={`Позвонить ${PHONES[0].display}`}
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-ink-600 bg-ink-850/80 text-white sm:hidden"
          >
            <IconPhone className="h-5 w-5" />
          </a>

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? "Закрыть меню" : "Открыть меню"}
            aria-expanded={open}
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-ink-600 bg-ink-850/80 text-white lg:hidden"
          >
            <span className="relative block h-4 w-5">
              <span
                className={`absolute left-0 h-0.5 w-5 bg-current transition-all duration-300 ${
                  open ? "top-[7px] rotate-45" : "top-0"
                }`}
              />
              <span
                className={`absolute left-0 top-[7px] h-0.5 w-5 bg-current transition-opacity duration-200 ${
                  open ? "opacity-0" : "opacity-100"
                }`}
              />
              <span
                className={`absolute left-0 h-0.5 w-5 bg-current transition-all duration-300 ${
                  open ? "top-[7px] -rotate-45" : "top-[14px]"
                }`}
              />
            </span>
          </button>
        </div>
      </div>

      {/* мобильное меню */}
      <div
        className={`overflow-hidden border-t border-ink-700/60 bg-ink-950/95 backdrop-blur-md transition-[max-height,opacity] duration-400 lg:hidden ${
          open ? "max-h-[80vh] opacity-100" : "max-h-0 opacity-0"
        }`}
      >
        <nav className="flex flex-col gap-1 px-5 py-4">
          {NAV.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="rounded-xl px-4 py-3.5 text-base font-medium text-mist-200 transition-colors hover:bg-ink-800 hover:text-white"
            >
              {item.label}
            </a>
          ))}
          <a
            href="#contact"
            onClick={() => setOpen(false)}
            className="btn btn-primary mt-2 w-full"
          >
            Оставить заявку
          </a>
        </nav>
      </div>
    </header>
  );
}
