"use client";

import { useState } from "react";
import Image from "next/image";
import { Reveal } from "@/components/ui/Reveal";
import { RequestButton } from "@/components/site/RequestButton";

export type Device = {
  id: string;
  brand: string;
  image: { src: string; width: number; height: number };
  /** во сколько модель «крупнее» соседей — чтобы масштабы в ряду читались честно */
  scale: string;
  name: string;
  badge: string;
  summary: string;
  specs: string[];
  fits: string;
};

export type Group = {
  id: string;
  title: string;
  note: string;
  /** начало alt-подписи к фотографии */
  alt: string;
  /** по чему фильтровать группу: по производителям внутри неё или целиком */
  filterBy: "brand" | "group";
  items: Device[];
};

const ALL = "Все";

/** Сколько моделей показывать в группе до нажатия «Показать ещё».
    Шесть — это два полных ряда на десктопе, лента не растягивается. */
const LIMIT = 6;

/** Ключ, по которому модель попадает под кнопку фильтра. */
function keyOf(group: Group, device: Device) {
  return group.filterBy === "brand" ? device.brand : group.title;
}

function Card({
  device,
  alt,
  priority,
  delay,
}: {
  device: Device;
  alt: string;
  priority: boolean;
  delay: number;
}) {
  return (
    <Reveal delay={delay} className="h-full">
      <article className="card card-sheen card-hover group flex h-full flex-col overflow-hidden">
        {/* витрина */}
        <div className="relative flex h-72 items-center justify-center overflow-hidden border-b border-ink-700/60 bg-ink-950/40">
          <div className="bg-grid absolute inset-0 opacity-25" />
          <div className="absolute inset-0 bg-[radial-gradient(62%_52%_at_50%_36%,rgba(255,255,255,0.08),transparent_72%)]" />
          <span className="absolute left-5 top-5 z-10 rounded-full border border-ink-600 bg-ink-950/85 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-mist-300">
            {device.badge}
          </span>
          <Image
            src={device.image.src}
            width={device.image.width}
            height={device.image.height}
            alt={`${alt} ${device.name}`}
            priority={priority}
            sizes="(max-width: 1024px) 90vw, 380px"
            className={`relative w-auto ${device.scale} object-contain drop-shadow-[0_22px_26px_rgba(0,0,0,0.65)] transition-transform duration-500 ease-out group-hover:-translate-y-1.5 group-hover:scale-[1.03]`}
          />
        </div>

        {/* описание */}
        <div className="flex flex-1 flex-col p-7">
          <h4 className="text-2xl font-bold">{device.name}</h4>
          <p className="mt-3 text-[15px] leading-relaxed text-mist-400">{device.summary}</p>

          <ul className="mt-6 space-y-2.5">
            {device.specs.map((spec) => (
              <li key={spec} className="flex gap-3 text-sm text-mist-300">
                <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-accent/70" />
                {spec}
              </li>
            ))}
          </ul>

          <p className="mt-6 rounded-xl border border-ink-700/70 bg-ink-950/50 px-4 py-3 text-sm text-mist-400">
            <span className="font-semibold text-mist-200">Подойдёт: </span>
            {device.fits}
          </p>

          <div className="mt-7 flex-1" />
          <RequestButton model={device.name}>Запросить условия</RequestButton>
        </div>
      </article>
    </Reveal>
  );
}

/**
 * Каталог касс с одним переключателем на весь блок: производители смарт-терминалов
 * и фискальные регистраторы стоят в одном ряду кнопок — покупателю неважно, что
 * это разные основания деления, ему важно быстро сузить выбор.
 *
 * Невыбранное не размонтируется, а прячется классом hidden: вся линейка остаётся
 * в разметке страницы — и для поисковиков, и на случай, если не отработал JavaScript.
 */
export function DeviceCatalog({ groups }: { groups: Group[] }) {
  const options = [
    ALL,
    ...new Set(groups.flatMap((g) => g.items.map((d) => keyOf(g, d)))),
  ];
  const [active, setActive] = useState(ALL);
  const [opened, setOpened] = useState<string[]>([]);
  const shown = (g: Group, d: Device) => active === ALL || keyOf(g, d) === active;

  return (
    <>
      <Reveal delay={60}>
        <div className="mt-8 flex flex-wrap gap-2" role="group" aria-label="Что показать">
          {options.map((option) => {
            const count =
              option === ALL
                ? groups.reduce((n, g) => n + g.items.length, 0)
                : groups.reduce(
                    (n, g) => n + g.items.filter((d) => keyOf(g, d) === option).length,
                    0,
                  );
            const on = active === option;
            return (
              <button
                key={option}
                type="button"
                onClick={() => setActive(option)}
                aria-pressed={on}
                // на телефоне кнопка должна быть не меньше 44 точек:
                // пальцем в 38 попадаешь через раз
                className={`inline-flex min-h-11 items-center rounded-full border px-4 text-sm font-semibold transition-colors sm:min-h-0 sm:py-2 ${
                  on
                    ? "border-accent-deep bg-accent text-ink-950"
                    : "border-ink-600 bg-ink-850/60 text-mist-300 hover:border-mist-400/60 hover:text-white"
                }`}
              >
                {option}
                <span className={`ml-2 text-xs ${on ? "text-ink-950/60" : "text-mist-500"}`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </Reveal>

      {groups.map((group, gi) => {
        const visible = group.items.filter((d) => shown(group, d));
        const open = opened.includes(group.id);
        const hiddenCount = Math.max(0, visible.length - LIMIT);
        // Показываем первые LIMIT из подходящих под фильтр. Остальные не
        // размонтируются, а прячутся — вся линейка остаётся в разметке страницы.
        const onScreen = new Set((open ? visible : visible.slice(0, LIMIT)).map((d) => d.id));
        return (
          <div
            key={group.id}
            className={visible.length === 0 ? "hidden" : gi === 0 ? "mt-12" : "mt-20"}
          >
            <Reveal>
              <div className="max-w-3xl border-l-2 border-accent/50 pl-5">
                <h3 className="text-2xl font-bold sm:text-[28px]">{group.title}</h3>
                <p className="mt-2.5 text-[15px] leading-relaxed text-mist-400">{group.note}</p>
              </div>
            </Reveal>

            <div className="mt-8 grid gap-5 lg:grid-cols-3">
              {group.items.map((device, i) => (
                <div key={device.id} className={onScreen.has(device.id) ? "h-full" : "hidden"}>
                  <Card
                    device={device}
                    alt={group.alt}
                    priority={gi === 0 && i === 0}
                    delay={(i % 3) * 100}
                  />
                </div>
              ))}
            </div>

            {hiddenCount > 0 && (
              <div className="mt-8 flex justify-center">
                <button
                  type="button"
                  onClick={() =>
                    setOpened((prev) =>
                      open ? prev.filter((id) => id !== group.id) : [...prev, group.id],
                    )
                  }
                  aria-expanded={open}
                  className="btn btn-ghost min-h-11"
                >
                  {open ? "Свернуть" : `Показать ещё ${hiddenCount}`}
                </button>
              </div>
            )}
          </div>
        );
      })}
    </>
  );
}
