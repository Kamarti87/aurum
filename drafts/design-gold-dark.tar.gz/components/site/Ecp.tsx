import Image from "next/image";
import { Reveal } from "@/components/ui/Reveal";
import { RequestButton } from "@/components/site/RequestButton";
import { IconArrow, IconDoc, IconKey, IconShield, IconWrench } from "@/components/ui/Icons";

type Token = {
  id: string;
  image: { src: string; width: number; height: number };
  scale: string;
  name: string;
  badge: string;
  summary: string;
  specs: string[];
};

/** Носители различаются не ёмкостью, а тем, где происходит подпись: у Lite — в
    программе на компьютере, у ЭЦП 3.0 — внутри самого устройства. Версия NFC Slim
    считает ту же криптографию, но её можно приложить к смартфону. */
const TOKENS: Token[] = [
  {
    id: "lite",
    image: { src: "/products/rutoken-lite.png", width: 895, height: 340 },
    scale: "max-h-[52%]",
    name: "Рутокен Lite",
    badge: "Базовый носитель",
    summary:
      "Хранит ключ подписи и сертификат. Сам не подписывает — криптографию считает программа на компьютере, поэтому к нему нужен криптопровайдер.",
    specs: [
      "Готов к работе сразу, драйверы ставить не нужно",
      "Совместим с программными криптопровайдерами",
      "Сертифицирован ФСТЭК России",
      "Подойдёт для получения подписи в УЦ ФНС",
    ],
  },
  {
    id: "ecp3",
    image: { src: "/products/rutoken-ecp3.png", width: 1239, height: 480 },
    scale: "max-h-[53%]",
    name: "Рутокен ЭЦП 3.0",
    badge: "Аппаратное СКЗИ",
    summary:
      "Подписывает внутри себя: криптография считается в самом устройстве, а ключ не копируется в память компьютера.",
    specs: [
      "ГОСТ Р 34.10-2012 с ключом 256 и 512 бит",
      "Шифры Магма и Кузнечик, а также RSA и ECDSA",
      "Криптооперации без выгрузки ключа наружу",
      "Подойдёт для УЦ ФНС и для ЕГАИС",
    ],
  },
  {
    id: "ecp3-nfc",
    image: { src: "/products/rutoken-ecp3-nfc-slim.png", width: 1100, height: 745 },
    scale: "max-h-[54%]",
    name: "Рутокен ЭЦП 3.0 3100 NFC Slim",
    badge: "Подпись со смартфона",
    summary:
      "Обновлённая линейка в тонком корпусе Slim с интерфейсом NFC: подписывать можно и с компьютера, и со смартфона — достаточно приложить носитель.",
    specs: [
      "Одобрен УЦ ФНС: торги, отчётность, ЭДО, госпорталы",
      "Ключ подписи хранится и используется внутри устройства",
      "Для работы по NFC сертификат выпускается как Активный ФКН",
      "Сертифицирован ФСБ и ФСТЭК России",
    ],
  },
];

const WORKS = [
  { Icon: IconKey, text: "Выпустим подпись физическому лицу" },
  { Icon: IconDoc, text: "Оформим машиночитаемую доверенность на сотрудника" },
  { Icon: IconShield, text: "Сделаем подпись для ЕГАИС и работы с алкоголем" },
  { Icon: IconWrench, text: "Настроим рабочее место, чтобы подпись заработала сразу" },
];

export function Ecp() {
  return (
    <section id="ecp" className="relative scroll-mt-24 overflow-hidden py-24 lg:py-32">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="orb left-0 top-32 h-[460px] w-[460px] text-accent/14" />
      </div>

      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="max-w-2xl">
            <Reveal>
              <span className="eyebrow">Электронная подпись</span>
            </Reveal>
            <Reveal delay={80}>
              <h2 className="mt-5 text-4xl font-semibold leading-tight sm:text-5xl">
                ЭЦП, Рутокен и <span className="text-hl">КриптоПро</span>
              </h2>
            </Reveal>
            <Reveal delay={140}>
              <p className="mt-5 text-lg text-mist-400">
                Подпись — это три вещи сразу: сертификат, носитель, на котором он лежит, и
                программа, которая подписывает. Выпустим сертификат, подберём носитель и
                настроим рабочее место, чтобы всё заработало вместе.
              </p>
            </Reveal>
          </div>

          <Reveal delay={200}>
            <a href="#contact" className="btn btn-ghost">
              Не знаете, что выбрать? Поможем
              <IconArrow className="h-4 w-4" />
            </a>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {TOKENS.map((token, i) => (
            <Reveal key={token.id} delay={i * 100} className="h-full">
              <article className="card card-sheen card-hover group flex h-full flex-col overflow-hidden">
                <div className="relative flex h-72 items-center justify-center overflow-hidden border-b border-ink-700/60 bg-ink-950/40">
                  <div className="bg-grid absolute inset-0 opacity-25" />
                  <div className="absolute inset-0 bg-[radial-gradient(62%_52%_at_50%_36%,rgba(255,255,255,0.08),transparent_72%)]" />
                  <span className="absolute left-5 top-5 z-10 rounded-full border border-ink-600 bg-ink-950/85 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-mist-300">
                    {token.badge}
                  </span>
                  <Image
                    src={token.image.src}
                    width={token.image.width}
                    height={token.image.height}
                    alt={`Носитель ${token.name}`}
                    sizes="(max-width: 1024px) 90vw, 520px"
                    className={`relative w-auto max-w-[88%] ${token.scale} object-contain drop-shadow-[0_22px_26px_rgba(0,0,0,0.65)] transition-transform duration-500 ease-out group-hover:-translate-y-1.5 group-hover:scale-[1.03]`}
                  />
                </div>

                <div className="flex flex-1 flex-col p-7">
                  <h3 className="text-2xl font-bold">{token.name}</h3>
                  <p className="mt-3 text-[15px] leading-relaxed text-mist-400">{token.summary}</p>

                  <ul className="mt-6 space-y-2.5">
                    {token.specs.map((spec) => (
                      <li key={spec} className="flex gap-3 text-sm text-mist-300">
                        <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-accent/70" />
                        {spec}
                      </li>
                    ))}
                  </ul>

                  <div className="mt-7 flex-1" />
                  <RequestButton model={token.name}>Оставить заявку</RequestButton>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        <div className="mt-5 grid gap-5 lg:grid-cols-2">
          <Reveal className="h-full">
            <div className="card flex h-full flex-col p-7">
              <h3 className="text-lg font-bold">КриптоПро CSP</h3>
              <p className="mt-2.5 text-[15px] leading-relaxed text-mist-400">
                Та самая программа, которая формирует и проверяет подпись. Носителю базового
                уровня без неё не обойтись, поэтому её обычно берут вместе с Рутокеном.
              </p>
              <ul className="mt-6 space-y-2.5">
                <li className="flex gap-3 text-sm text-mist-300">
                  <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-accent/70" />
                  ГОСТ Р 34.10-2012 и 34.11-2012, шифрование по 34.12-2015
                </li>
                <li className="flex gap-3 text-sm text-mist-300">
                  <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-accent/70" />
                  Windows, macOS, Linux, iOS и Android
                </li>
                <li className="flex gap-3 text-sm text-mist-300">
                  <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-accent/70" />
                  Лицензия покупается отдельно, у вендора есть пробная на 90 дней
                </li>
              </ul>
              <div className="mt-7 flex-1" />
              <RequestButton model="КриптоПро CSP">Оставить заявку</RequestButton>
            </div>
          </Reveal>

          <Reveal delay={100} className="h-full">
            <div className="card flex h-full flex-col p-7">
              <h3 className="text-lg font-bold">Что берём на себя</h3>
              <ul className="mt-6 space-y-4">
                {WORKS.map(({ Icon, text }) => (
                  <li key={text} className="flex items-start gap-4">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-ink-600 bg-ink-850 text-mist-300">
                      <Icon className="h-5 w-5" />
                    </span>
                    <p className="pt-2 text-[15px] leading-snug text-mist-300">{text}</p>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
